import React from 'react'
import ItemListContainer from '../../components/ItemListContainer/ItemListContainer'
import Carousel from "../../components/Carrousel/Carrousel"

const Home = () => {
  return (
    <div>
      <Carousel/>
      <h1 className='text-gray-700 font-bold text-4xl  m-auto mt-12 mb-12 w-96 hover:text-gray-900 hover:cursor-pointer'>Nuestros productos</h1>
    <ItemListContainer/>
    </div>
  )
}

export default Home